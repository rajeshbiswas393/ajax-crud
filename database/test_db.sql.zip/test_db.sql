-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2021 at 01:28 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `upload_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`upload_id`, `name`, `type`, `created_at`) VALUES
(1, 'young-user-icon.jpg', 'image/jpg', '2021-07-08 05:36:42'),
(2, '1626159340_08eca5bbd270696ae32f.jpg', 'image/jpeg', '2021-07-13 01:55:40'),
(3, '1626159540_250fb70c9311e03d4803.jpg', 'image/jpeg', '2021-07-13 01:59:00'),
(4, '1626159543_19b776075e2e0188ffb8.jpg', 'image/jpeg', '2021-07-13 01:59:03'),
(5, '1626160431_c726ae22b3fbf6958aa1.jpg', 'image/jpeg', '2021-07-13 02:13:51'),
(6, '1626161933_f1083e08fdb2c5a7f262.jpg', 'image/jpeg', '2021-07-13 02:38:53'),
(7, '1626162007_ca011056af4b210f9716.jpg', 'image/jpeg', '2021-07-13 02:40:07'),
(8, '1626173100_b24423cca2ea03d9037a.jpg', 'image/jpeg', '2021-07-13 05:45:00'),
(9, '1626173142_f1b8572a7bf768330cf8.jpg', 'image/jpeg', '2021-07-13 05:45:42'),
(10, '1626173259_c39ac7ef460183bf10c0.jpg', 'image/jpeg', '2021-07-13 05:47:39'),
(11, '1626173343_3e36c29dbeb4f7dfec1e.jpg', 'image/jpeg', '2021-07-13 05:49:03'),
(12, '1626173409_e3eaab344d5de10b021f.jpg', 'image/jpeg', '2021-07-13 05:50:09'),
(13, '1626173491_092c6ef5add071753605.jpg', 'image/jpeg', '2021-07-13 05:51:31'),
(14, '1626173543_321b71502a19f9f44b27.jpg', 'image/jpeg', '2021-07-13 05:52:23'),
(15, '1626174802_82f701071c75edbc720a.jpg', 'image/jpeg', '2021-07-13 06:13:22');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `profile_picture_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `full_name`, `email`, `phone_no`, `profile_picture_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Rajesh Biswas', 'rajesh.biswas393@gmail.com', '8697853766', 1, 1, '2021-07-08 05:26:04', '2021-07-08 05:26:04'),
(2, 'Rohit Kumar', 'rohit.kumar1990@gmail.com', '8776567845', 1, 1, '2021-07-08 05:28:28', '2021-07-08 05:28:28'),
(3, 'Rahid Khan', 'rasid.khan1994@gmail.com', '8697853766', 1, 1, '2021-07-08 05:30:34', '2021-07-08 05:30:34'),
(4, 'Rahini Sil', 'rohini.rani1992@gmail.com', '7890457845', 5, 1, '2021-07-13 02:13:51', '2021-07-13 06:12:39'),
(6, 'Dip Sarkar', 'dip.sarkar1992@gmail.com', '8967456623', 7, 1, '2021-07-13 02:40:07', '2021-07-13 02:40:07'),
(7, 'Kiara Adbani', 'kiara.adbani393@gmail.com', '7890563425', 8, 1, '2021-07-13 05:45:00', '2021-07-13 05:45:00'),
(8, 'Salman Khan', 'salman.khan1990@gmail.com', '8967453436', 9, 1, '2021-07-13 05:45:42', '2021-07-13 05:45:42'),
(9, 'Imran Khan', 'imran.khan2002@gmail.com', '7890568790', 10, 1, '2021-07-13 05:47:39', '2021-07-13 05:47:39'),
(10, 'Mosure Rahaman Khan', 'mosure.rahaman1885@gmail.com', '9056753425', 11, 1, '2021-07-13 05:49:03', '2021-07-13 05:49:03'),
(11, 'Saikat Dasgupta', 'saikat.datgupta456@gmail.com', '7689564536', 12, 1, '2021-07-13 05:50:09', '2021-07-13 05:50:09'),
(12, 'Rahul David', 'rahul.david345@hotmail.com', '9556453627', 13, 1, '2021-07-13 05:51:31', '2021-07-13 05:51:31'),
(13, 'Michel Henry', 'ricky.ponting@gmail.com', '7890453789', 15, 1, '2021-07-13 05:52:23', '2021-07-13 06:13:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
